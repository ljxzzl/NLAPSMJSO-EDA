% 创建一个新的图形窗口
figure;

% 标题数组
titles = {'10D of the IEEE CEC 2017 test suite', '30D of the IEEE CEC  2017 test suite', ...
          '50D of the IEEE CEC  2017 test suite', '100D of the IEEE CEC  2017 test suite', ...
          'Mean of the IEEE CEC  2017 test suite'};

% 用subplot函数创建5个子图
for i = 1:4
    subplot(2, 2, i);
    % 读取并显示每个 PNG 图像
    img = imread(sprintf('untitled%d.png', i)); % 假设文件名为 untitled1.png, untitled2.png, ..., untitled5.png
    imshow(img);
    title(titles{i}); % 给每个子图添加相应的标题
end

% 导出图形为高分辨率的 PNG 文件
exportgraphics(gcf, 'figure.png', 'Resolution', 900);
