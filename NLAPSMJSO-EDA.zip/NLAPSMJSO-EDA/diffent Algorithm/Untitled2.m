file_path = 'lshadeepsin.txt';  % 替换为你的文件路径
file_contents = fileread(file_path);

% 打开新的 txt 文件以保存处理后的内容
output_file_path = 'lshadeepsin-dispose.txt';  % 替换为你想要保存的文件路径
fid = fopen(output_file_path, 'w');

% 使用正则表达式匹配括号里的内容并将其替换为空字符串
pattern = '\([^)]*\)'; % 匹配括号及其内容
file_contents = regexprep(file_contents, pattern, '');

% 将处理后的内容写入新文件
fprintf(fid, '%s', file_contents);

% 关闭文件
fclose(fid);

disp('已将括号里的内容移除，并将结果保存到新文件中。');
