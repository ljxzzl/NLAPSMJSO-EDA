% 定义X轴的数据
x = {'10D', '30D', '50D', '100D', 'Mean'};

% 定义7条Y轴的数据
y1 = [3.6724,2.6207,2.4310,2.7931,2.8793];
y2 = [3.9483,3.6379,3.6379,3.6552,3.7198];
y3 = [3.7759, 	3.3966,	3.1897,	3.4138,3.4440];
y4 = [4.8103,	4.0862, 3.8793,	3.0517,3.9569];
y5 = [3.7931, 	6.4655, 6.5862,7,5.9612];
y6 = [4.2414, 	4.2414, 4.4655,	4.6897,4.4095];
y7 = [3.7586,	3.5517,	3.8103,	3.3966,	3.6293];

% 定义颜色矩阵，每行是一个RGB三元组
colors = [
    1, 0, 0; % 红色
    0, 1, 0; % 绿色
    0, 0, 1; % 蓝色
    1, 1, 0; % 黄色
    1, 0, 1; % 品红色
    0, 1, 1; % 青色
    0.5, 0.5, 0.5 % 灰色
];

% 创建折线图
figure; % 创建一个新的图窗

% 绘制每条线，并指定颜色
hold on; % 保持当前图形，以便叠加多条线
plot(1:length(x), y1, '-o', 'Color', colors(1,:));
plot(1:length(x), y2, '-o', 'Color', colors(2,:));
plot(1:length(x), y3, '-o', 'Color', colors(3,:));
plot(1:length(x), y4, '-o', 'Color', colors(4,:));
plot(1:length(x), y5, '-o', 'Color', colors(5,:));
plot(1:length(x), y6, '-o', 'Color', colors(6,:));
plot(1:length(x), y7, '-o', 'Color', colors(7,:));
hold off; % 释放图形保持状态

% 设置X轴的刻度和标签
set(gca, 'XTick', 1:length(x), 'XTickLabel', x);

% 添加图例
legend('NLAPSMJSO-EDA', 'APSM-JSO', 'IDE-EDA', 'LSHADE-epsin', 'MadDe', 'LSHADE', 'EBOwithCMAR');

% 添加标题和轴标签
title('Rankings of 7 algorithms from Friedman test');
xlabel('Dimension');
ylabel('Rankings');

% 显示网格线
grid on;
exportgraphics(gcf, 'figure.png', 'Resolution', 900);

