% % 读取 TXT 文件内容
% file_path = 'scores_summaryNLPjso.txt';  % 替换为你的文件路径
% file_contents = fileread(file_path);
% 
% % 提取平均值和标准差
% pattern = '平均值 = (\d+\.\d+), 标准差 = (\d+\.\d+)';
% matches = regexp(file_contents, pattern, 'tokens');
% 
% % 将提取的值替换为所需的格式
% for i = 1:numel(matches)
%     mean_value = matches{i}{1};
%     std_dev_value = matches{i}{2};
% %     modified_value = sprintf('%s(%s)', mean_value, std_dev_value);
%     modified_value = sprintf('%s', mean_value);
% %     file_contents = regexprep(file_contents, pattern, modified_value, 'once');
%      file_contents = regexprep(file_contents, pattern, modified_value, 'once');
% end
% 
% % 写入修改后的内容到新的 TXT 文件
% output_file_path = 'path_to_output_file.txt';  % 替换为你想要保存的文件路径
% fid = fopen(output_file_path, 'w');
% fprintf(fid, '%s', file_contents);
% fclose(fid);
% 
% disp('修改后的内容已写入新文件。');
% 读取 TXT 文件内容
file_path = 'summaryNLPjso150dim.txt';  % 替换为你的文件路径
file_contents = fileread(file_path);

% 提取平均值和标准差
pattern = '函数\s+\w+\s+在维度\s+\d+:\s+平均值 = (\d+\.\d+),\s+标准差 = \d+\.\d+';
matches = regexp(file_contents, pattern, 'tokens');

% 将提取的值替换为所需的格式
for i = 1:numel(matches)
    mean_value = matches{i}{1};
    modified_value = sprintf('%s', mean_value);
    file_contents = regexprep(file_contents, pattern, modified_value, 'once');
end

% 写入修改后的内容到新的 TXT 文件
output_file_path = 'NLPjso150dim.txt';  % 替换为你想要保存的文件路径
fid = fopen(output_file_path, 'w');
fprintf(fid, '%s', file_contents);
fclose(fid);

disp('修改后的内容已写入新文件。');
