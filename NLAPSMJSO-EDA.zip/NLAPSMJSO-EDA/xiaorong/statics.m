% 定义X轴的数据
x = {'10D', '30D', '50D', '100D', 'Mean'};

% 定义7条Y轴的数据
y1 = [2.1724	1.7414	1.6897	2.0517 	1.9138  ];
y2 = [3.5172  	3.4828 	3.6897	3.7241 	3.6034 ];
y3 = [2.2069	2.1207 	2.1207	1.9138 	2.0905];
y4 = [2.1034	2.6552	2.500	2.3103	2.3922];


% 定义颜色矩阵，每行是一个RGB三元组
colors = [
    1, 0, 0; % 红色
    0, 1, 0; % 绿色
    0, 0, 1; % 蓝色
    1, 1, 0; % 黄色
    1, 0, 1; % 品红色
    0, 1, 1; % 青色
    0.5, 0.5, 0.5 % 灰色
];

% 创建折线图
figure; % 创建一个新的图窗

% 绘制每条线，并指定颜色
hold on; % 保持当前图形，以便叠加多条线
plot(1:length(x), y1, '-o', 'Color', colors(1,:));
plot(1:length(x), y2, '-o', 'Color', colors(2,:));
plot(1:length(x), y3, '-o', 'Color', colors(3,:));
plot(1:length(x), y4, '-o', 'Color', colors(4,:));

hold off; % 释放图形保持状态

% 设置X轴的刻度和标签
set(gca, 'XTick', 1:length(x), 'XTickLabel', x);

% 添加图例
legend('NLAPSMJSO-EDA', 'APSMJSO-EDA', 'NLAPSMJSO', 'APSMJSO');

% 添加标题和轴标签
title('Rankings of 4 algorithms from Friedman test');
xlabel('Dimension');
ylabel('Rankings');

% 显示网格线
grid on;
exportgraphics(gcf, 'figure.png', 'Resolution', 900);
% 如果需要，可以调整轴的范围
% axis([xmin xmax ymin ymax]);

% 保存图像为文件（例如PNG格式）
% saveas(gcf, '多条线折线图.png');
