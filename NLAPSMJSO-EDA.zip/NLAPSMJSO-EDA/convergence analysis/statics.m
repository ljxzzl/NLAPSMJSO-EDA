% 数据：各年份前五个风电整机制造商的新增吊装容量变化 (单位：GW)
years = [2018, 2019, 2020, 2021, 2022, 2023];
companies = {'金风科技', '远景能源', '运达股份', '明阳智能', '三一重能'};

% 各公司对应的新增吊装容量数据（单位：GW）
installation_capacity = [
    6.7, 8.01, 12.28, 11.38, 11.36, 15.67;   % 金风科技
    3.7, 5.42, 9.13, 8.15, 7.82, 14.84;       % 远景能源
    1.3, 2.06, 3.65, 6.77, 6.10, 10.38;       % 运达股份
    2.5, 4.50, 5.51, 6.93, 6.21, 9.02;        % 明阳智能
    0, 0, 3.03, 3.21, 4.52, 7.76                 % 三一重能
];

% 绘制新增吊装容量变化图
figure;
hold on;

% 为每个公司绘制新增吊装容量变化曲线
plot(years, installation_capacity(1,:), '-o', 'DisplayName', '金风科技', 'LineWidth', 2);
plot(years, installation_capacity(2,:), '-s', 'DisplayName', '远景能源', 'LineWidth', 2);
plot(years, installation_capacity(3,:), '-^', 'DisplayName', '运达股份', 'LineWidth', 2);
plot(years, installation_capacity(4,:), '-d', 'DisplayName', '明阳智能', 'LineWidth', 2);
plot(years, installation_capacity(5,:), '-p', 'DisplayName', '三一重能', 'LineWidth', 2);

% 图表设置
title('前五个风电整机制造商新增吊装容量变化（2018-2023）', 'FontSize', 14);
xlabel('年份', 'FontSize', 12);
ylabel('新增吊装容量 (GW)', 'FontSize', 12);
xticks(years);
legend('show', 'Location', 'best');
grid on;
hold off;
