% 加载所有 .mat 文件
files = {'NLAPSMJSO_EDA.mat', 'APSM_JSO.mat', 'IDE_EDA.mat', ...
         'LSHADE_cnEpSin.mat', 'MadDE.mat', 'LSHADE.mat', 'EBOwithCMAR.mat'};
     
means = cell(1, length(files));
diversityScoresList = cell(1, length(files));

% 加载每个文件并存储 diversityScores 变量
for i = 1:length(files)
    data = load(files{i});
    diversityScoresList{i} = data.covergenceScores;
end

% 获取 cell 数组的大小
[numRows, numCols] = size(diversityScoresList{1});

% 初始化一个数组来存储每个文件的均值
for i = 1:length(files)
    means{i} = cell(1, numCols);
end

% 计算每个文件中每一列的均值
for i = 1:length(files)
    diversityScores = diversityScoresList{i};
    for col = 1:numCols
        % 找到最长的数组长度
        maxLength = 0;
        for row = 1:numRows
            maxLength = max(maxLength, length(diversityScores{row, col}));
        end
        
        % 找到第一个数组的最小值，用于填充NaN
        minValue = min(diversityScores{1, col});
        
        % 初始化一个NaN填充的数组
        columnData = NaN(numRows, maxLength);
        
        % 填充数据
        for row = 1:numRows
            currentLength = length(diversityScores{row, col});
            columnData(row, 1:currentLength) = diversityScores{row, col};
        end
        
        % 用第一个数组的最小值填充NaN
        columnData(isnan(columnData)) = minValue;
        
        % 计算均值
        means{i}{col} = mean(columnData, 1);
    end
end

% 指定要绘制的列
colsToPlot = [10, 21, 23, 30];

% 创建一个新的图形窗口
figure;

% 定义颜色数组
colors = ['r', 'g', 'b', 'k', 'm', 'c', 'y'];  % 红, 绿, 蓝, 黑, 品红, 青, 黄

% 绘制每一列的均值在不同的子图中
for i = 1:length(colsToPlot)
    col = colsToPlot(i);
    subplot(2, 2, i);  % 创建一个 3x2 的子图布局
    hold on;
    for j = 1:length(files)
        plot(means{j}{col}, 'Color', colors(j), 'LineWidth', 2); 
    end
    hold off;
    title(['F' num2str(col) ' Mean Values']);
    xlabel('Index');
    ylabel('Convergence Scores Mean Value');
    grid on;
    legend('NLAPSMJSO_EDA', 'APSM_JSO', 'IDE_EDA', 'LSHADE_cnEpSin', 'MadDE', 'LSHADE','EBOwithCMAR');
end

set(gcf, 'Units', 'Inches', 'Position', [0, 0, 15, 12]);
% 保存图像为 PDF（或者你可以选择 EPS 等矢量格式）
print('combined_means.png', '-dpng', '-r900');

