% 提取每种方法的 T1 值
clear all;
T1_NLAPSMJSO_EDA = [ 1.226, 1.625, 2.2714, 4.9843];
T1_APSM_JSO = [ 0.53444, 0.83476, 1.4713, 3.8481];
T1_IDE_EDA = [ 0.79588, 0.93951, 1.4045, 3.4901];
T1_LSHADE_epsin = [ 5.0953, 3.4586, 3.1253, 7.5536];
T1_MadDe = [ 1.4166, 1.6756, 5.03, 120.5304];
T1_LSHADE = [ 1.0156, 1.1213, 1.5393, 4.4489];
T1_EBOwithCMAR = [1.8406, 2.6243, 3.9485, 12.5436];
% 组合成一个 7 行 4 列的矩阵
T1_matrix = [T1_NLAPSMJSO_EDA; T1_APSM_JSO; T1_IDE_EDA; T1_LSHADE_epsin; T1_MadDe; T1_LSHADE; T1_EBOwithCMAR];

T2_matrix=[
    1.0193	1.6883	2.237	5.0769
    0.41705	0.86102	1.4572	3.7817
    0.5881	0.90895	1.3757	3.4984
    5.1412 	3.4443	3.1161	7.4998
    1.1175	1.3686	4.7020	114.9105
    0.78221 0.93036	1.3424	4.2259
    1.8511	2.5996	4.0179 	12.3922
    ]
% 显示结果
abs_diff = abs(T2_matrix - T1_matrix);
divided_result = abs_diff/0.0212; % 在这里替换 "your_number" 为你想要的除数
format short;
disp('差值绝对值除以一个数的结果:');
disp(divided_result);