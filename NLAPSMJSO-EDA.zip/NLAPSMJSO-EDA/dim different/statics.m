% 定义X轴的数据
x = {'10D', '30D', '50D', '100D', 'Mean'};

% 定义7条Y轴的数据
y1 = [2.8966	3.0862	2.9828	3.1034	3.0172];
y2 = [2.2931	2.2759	2.2414	2.4138	2.3060];
y3 = [2.3793 	2.2069	2.4655 	2.5172	2.3922];
y4 = [2.4310	2.4310	2.3103	1.9655	2.2845];


% 定义颜色矩阵，每行是一个RGB三元组
colors = [
    1, 0, 0; % 红色
    0, 1, 0; % 绿色
    0, 0, 1; % 蓝色
    1, 1, 0; % 黄色
    1, 0, 1; % 品红色
    0, 1, 1; % 青色
    0.5, 0.5, 0.5 % 灰色
];

% 创建折线图
figure; % 创建一个新的图窗

% 绘制每条线，并指定颜色
hold on; % 保持当前图形，以便叠加多条线
plot(1:length(x), y1, '-o', 'Color', colors(1,:));
plot(1:length(x), y2, '-o', 'Color', colors(2,:));
plot(1:length(x), y3, '-o', 'Color', colors(3,:));
plot(1:length(x), y4, '-o', 'Color', colors(4,:));

hold off; % 释放图形保持状态

% 设置X轴的刻度和标签
set(gca, 'XTick', 1:length(x), 'XTickLabel', x);

% 添加图例
legend('75D^2/3', '100D^2/3', '125D^2/3', '150D^2/3');

% 添加标题和轴标签
title('Rankings of 4 parameter from Friedman test');
xlabel('Dimension');
ylabel('Rankings');

% 显示网格线
grid on;
exportgraphics(gcf, 'figure.png', 'Resolution', 900);
% 如果需要，可以调整轴的范围
% axis([xmin xmax ymin ymax]);

% 保存图像为文件（例如PNG格式）
% saveas(gcf, '多条线折线图.png');
